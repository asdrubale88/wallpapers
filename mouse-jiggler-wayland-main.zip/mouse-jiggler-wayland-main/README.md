Simple mouse jiggler which uses ydotool (and ydotoold) for a wayland session
